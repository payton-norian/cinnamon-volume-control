const Applet = imports.ui.applet;
const AppletPopupMenu = imports.ui.applet.AppletPopupMenu;
const Slider = imports.ui.slider;
const Util = imports.misc.util;
const St = imports.gi.St;
const PopupMenu = imports.ui.popupMenu;

function MyApplet(metadata, orientation, panel_height, instance_id) {
    this._init(metadata, orientation, panel_height, instance_id);
}

MyApplet.prototype = {
    __proto__: Applet.IconApplet.prototype,

    _init: function(metadata, orientation, panel_height, instance_id) {
        Applet.IconApplet.prototype._init.call(this, orientation, panel_height, instance_id);

        this.set_applet_icon_name('audio-speakers-symbolic');
        this.set_applet_tooltip(_("Управление звуком и микрофоном"));

        // Меню
        this.menuManager = new PopupMenu.PopupMenuManager(this);
        this.menu = new AppletPopupMenu(this, orientation);
        this.menuManager.addMenu(this.menu);

        let mainLayout = new St.BoxLayout({ vertical: true, style_class: 'main-layout' });

        // Speakers
        let sinkContainer = new St.BoxLayout({ vertical: false, style_class: 'slider-container' });
        let sinkIcon = new St.Icon({ icon_name: 'audio-speakers-symbolic', icon_type: St.IconType.SYMBOLIC, style_class: 'popup-menu-icon' });

        this.sinkSlider = new Slider.Slider(0.5);
        this.sinkSlider.connect('value-changed', (slider, value) => {
            let percent = Math.round(value * 100);
            Util.spawnCommandLine('pactl set-sink-volume @DEFAULT_SINK@ ' + percent + '%');
        });

        sinkContainer.add_actor(sinkIcon);
        sinkContainer.add_actor(this.sinkSlider.actor); 

        // Microphone
        let sourceContainer = new St.BoxLayout({ vertical: false, style_class: 'slider-container' });
        let sourceIcon = new St.Icon({ icon_name: 'audio-input-microphone-symbolic', icon_type: St.IconType.SYMBOLIC, style_class: 'popup-menu-icon' });

        this.sourceSlider = new Slider.Slider(0.5);
        this.sourceSlider.connect('value-changed', (slider, value) => {
            let percent = Math.round(value * 100);
            Util.spawnCommandLine('pactl set-source-volume @DEFAULT_SOURCE@ ' + percent + '%');
        });

        sourceContainer.add_actor(sourceIcon);
        sourceContainer.add_actor(this.sourceSlider.actor); 

        // Adding containers to the menu
        mainLayout.add_actor(sinkContainer);
        mainLayout.add_actor(sourceContainer);
        this.menu.addActor(mainLayout);
    },

    on_applet_clicked: function(event) {
        this.menu.toggle();
    }
};

function main(metadata, orientation, panel_height, instance_id) {
    return new MyApplet(metadata, orientation, panel_height, instance_id);
}
